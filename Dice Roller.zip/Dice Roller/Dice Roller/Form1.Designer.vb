﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbLooker = New System.Windows.Forms.ListBox()
        Me.btnRoll = New System.Windows.Forms.Button()
        Me.numD4 = New System.Windows.Forms.NumericUpDown()
        Me.numD6 = New System.Windows.Forms.NumericUpDown()
        Me.numD8 = New System.Windows.Forms.NumericUpDown()
        Me.numD10 = New System.Windows.Forms.NumericUpDown()
        Me.numD12 = New System.Windows.Forms.NumericUpDown()
        Me.numD20 = New System.Windows.Forms.NumericUpDown()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.ckbD4 = New System.Windows.Forms.CheckBox()
        Me.ckbD8 = New System.Windows.Forms.CheckBox()
        Me.ckbD6 = New System.Windows.Forms.CheckBox()
        Me.ckbD10 = New System.Windows.Forms.CheckBox()
        Me.ckbD12 = New System.Windows.Forms.CheckBox()
        Me.ckbD20 = New System.Windows.Forms.CheckBox()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.numD4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numD6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numD8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numD10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numD12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numD20, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 70.0!)
        Me.Label1.Location = New System.Drawing.Point(198, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(503, 107)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Dice Roller"
        '
        'lbLooker
        '
        Me.lbLooker.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lbLooker.FormattingEnabled = True
        Me.lbLooker.ItemHeight = 25
        Me.lbLooker.Location = New System.Drawing.Point(199, 120)
        Me.lbLooker.Name = "lbLooker"
        Me.lbLooker.Size = New System.Drawing.Size(485, 329)
        Me.lbLooker.TabIndex = 1
        '
        'btnRoll
        '
        Me.btnRoll.Font = New System.Drawing.Font("Microsoft Sans Serif", 50.0!)
        Me.btnRoll.Location = New System.Drawing.Point(29, 519)
        Me.btnRoll.Name = "btnRoll"
        Me.btnRoll.Size = New System.Drawing.Size(398, 90)
        Me.btnRoll.TabIndex = 8
        Me.btnRoll.Text = "Roll"
        Me.btnRoll.UseVisualStyleBackColor = True
        '
        'numD4
        '
        Me.numD4.Location = New System.Drawing.Point(29, 210)
        Me.numD4.Name = "numD4"
        Me.numD4.Size = New System.Drawing.Size(120, 20)
        Me.numD4.TabIndex = 24
        '
        'numD6
        '
        Me.numD6.Location = New System.Drawing.Point(29, 308)
        Me.numD6.Name = "numD6"
        Me.numD6.Size = New System.Drawing.Size(120, 20)
        Me.numD6.TabIndex = 25
        '
        'numD8
        '
        Me.numD8.Location = New System.Drawing.Point(29, 414)
        Me.numD8.Name = "numD8"
        Me.numD8.Size = New System.Drawing.Size(120, 20)
        Me.numD8.TabIndex = 26
        '
        'numD10
        '
        Me.numD10.Location = New System.Drawing.Point(714, 210)
        Me.numD10.Name = "numD10"
        Me.numD10.Size = New System.Drawing.Size(120, 20)
        Me.numD10.TabIndex = 27
        '
        'numD12
        '
        Me.numD12.Location = New System.Drawing.Point(714, 309)
        Me.numD12.Name = "numD12"
        Me.numD12.Size = New System.Drawing.Size(120, 20)
        Me.numD12.TabIndex = 28
        '
        'numD20
        '
        Me.numD20.Location = New System.Drawing.Point(714, 414)
        Me.numD20.Name = "numD20"
        Me.numD20.Size = New System.Drawing.Size(120, 20)
        Me.numD20.TabIndex = 29
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 50.0!)
        Me.btnReset.Location = New System.Drawing.Point(436, 519)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(398, 90)
        Me.btnReset.TabIndex = 30
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'ckbD4
        '
        Me.ckbD4.AutoSize = True
        Me.ckbD4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.ckbD4.Location = New System.Drawing.Point(60, 173)
        Me.ckbD4.Name = "ckbD4"
        Me.ckbD4.Size = New System.Drawing.Size(56, 29)
        Me.ckbD4.TabIndex = 31
        Me.ckbD4.Text = "D4"
        Me.ckbD4.UseVisualStyleBackColor = True
        '
        'ckbD8
        '
        Me.ckbD8.AutoSize = True
        Me.ckbD8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.ckbD8.Location = New System.Drawing.Point(60, 379)
        Me.ckbD8.Name = "ckbD8"
        Me.ckbD8.Size = New System.Drawing.Size(56, 29)
        Me.ckbD8.TabIndex = 32
        Me.ckbD8.Text = "D8"
        Me.ckbD8.UseVisualStyleBackColor = True
        '
        'ckbD6
        '
        Me.ckbD6.AutoSize = True
        Me.ckbD6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.ckbD6.Location = New System.Drawing.Point(60, 273)
        Me.ckbD6.Name = "ckbD6"
        Me.ckbD6.Size = New System.Drawing.Size(56, 29)
        Me.ckbD6.TabIndex = 33
        Me.ckbD6.Text = "D6"
        Me.ckbD6.UseVisualStyleBackColor = True
        '
        'ckbD10
        '
        Me.ckbD10.AutoSize = True
        Me.ckbD10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.ckbD10.Location = New System.Drawing.Point(736, 173)
        Me.ckbD10.Name = "ckbD10"
        Me.ckbD10.Size = New System.Drawing.Size(67, 29)
        Me.ckbD10.TabIndex = 34
        Me.ckbD10.Text = "D10"
        Me.ckbD10.UseVisualStyleBackColor = True
        '
        'ckbD12
        '
        Me.ckbD12.AutoSize = True
        Me.ckbD12.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.ckbD12.Location = New System.Drawing.Point(736, 273)
        Me.ckbD12.Name = "ckbD12"
        Me.ckbD12.Size = New System.Drawing.Size(67, 29)
        Me.ckbD12.TabIndex = 35
        Me.ckbD12.Text = "D12"
        Me.ckbD12.UseVisualStyleBackColor = True
        '
        'ckbD20
        '
        Me.ckbD20.AutoSize = True
        Me.ckbD20.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.ckbD20.Location = New System.Drawing.Point(736, 379)
        Me.ckbD20.Name = "ckbD20"
        Me.ckbD20.Size = New System.Drawing.Size(67, 29)
        Me.ckbD20.TabIndex = 36
        Me.ckbD20.Text = "D20"
        Me.ckbD20.UseVisualStyleBackColor = True
        '
        'txtTotal
        '
        Me.txtTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtTotal.Location = New System.Drawing.Point(320, 464)
        Me.txtTotal.Multiline = True
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(326, 37)
        Me.txtTotal.TabIndex = 37
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(267, 476)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "Total"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(865, 628)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.ckbD20)
        Me.Controls.Add(Me.ckbD12)
        Me.Controls.Add(Me.ckbD10)
        Me.Controls.Add(Me.ckbD6)
        Me.Controls.Add(Me.ckbD8)
        Me.Controls.Add(Me.ckbD4)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.numD20)
        Me.Controls.Add(Me.numD12)
        Me.Controls.Add(Me.numD10)
        Me.Controls.Add(Me.numD8)
        Me.Controls.Add(Me.numD6)
        Me.Controls.Add(Me.numD4)
        Me.Controls.Add(Me.btnRoll)
        Me.Controls.Add(Me.lbLooker)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = " Dice Roller"
        CType(Me.numD4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numD6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numD8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numD10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numD12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numD20, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents lbLooker As ListBox
    Friend WithEvents btnRoll As Button
    Friend WithEvents numD4 As NumericUpDown
    Friend WithEvents numD6 As NumericUpDown
    Friend WithEvents numD8 As NumericUpDown
    Friend WithEvents numD10 As NumericUpDown
    Friend WithEvents numD12 As NumericUpDown
    Friend WithEvents numD20 As NumericUpDown
    Friend WithEvents btnReset As Button
    Friend WithEvents ckbD4 As CheckBox
    Friend WithEvents ckbD8 As CheckBox
    Friend WithEvents ckbD6 As CheckBox
    Friend WithEvents ckbD10 As CheckBox
    Friend WithEvents ckbD12 As CheckBox
    Friend WithEvents ckbD20 As CheckBox
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents Label2 As Label
End Class
