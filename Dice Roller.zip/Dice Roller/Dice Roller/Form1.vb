﻿Public Class Form1
    'Global Variables
    Dim strD4 As String = ""
    Dim strD6 As String = ""
    Dim strD8 As String = ""
    Dim strD10 As String = ""
    Dim strD12 As String = ""
    Dim strD20 As String = ""

    Dim intD4 As Double = 0
    Dim intD6 As Double = 0
    Dim intD8 As Double = 0
    Dim intD10 As Double = 0
    Dim intD12 As Double = 0
    Dim intD20 As Double = 0

    Dim valueHolder(30) As Double
    Dim total As Double = 0
    Dim couter As Integer = 0

    Private Sub btnRoll_Click(sender As Object, e As EventArgs) Handles btnRoll.Click
        'This is the roll button which does a majority of the work

        'Checks to see if the D4 checkbox is checked
        If ckbD4.Checked = True Then
            For count As Integer = 0 To numD4.Value - 1
                intD4 = Roll(4)
                valueHolder(count) = intD4
                count = count + 1
                strD4 = strD4 & "d4(" & intD4 & ") "
            Next
        End If
        'Checks to see if the D6 checkbox is checked
        If ckbD6.Checked = True Then
            For count As Integer = 0 To numD6.Value - 1
                intD6 = Roll(6)
                valueHolder(count) = intD6
                count = count + 1
                strD6 = strD6 & "d6(" & intD6 & ") "
            Next
        End If
        'Checks to see if the D8 checkbox is checked
        If ckbD8.Checked = True Then
            For count As Integer = 0 To numD8.Value - 1
                intD8 = Roll(8)
                valueHolder(count) = intD8
                count = count + 1
                strD8 = strD8 & "d8(" & intD8 & ") "
            Next
        End If
        'Checks to see if the D10 checkbox is checked
        If ckbD10.Checked = True Then
            For count As Integer = 0 To numD10.Value - 1
                intD10 = Roll(10)
                valueHolder(count) = intD10
                count = count + 1
                strD10 = strD10 & "d10(" & intD10 & ") "
            Next
        End If
        'Checks to see if the D12 checkbox is checked
        If ckbD12.Checked = True Then
            For count As Integer = 0 To numD12.Value - 1
                Dim intD12 As Double = Roll(12)
                valueHolder(count) = intD12
                count = count + 1
                strD12 = strD12 & "d12(" & intD12 & ") "
            Next
        End If
        'Checks to see if the D20 checkbox is checked
        If ckbD20.Checked = True Then
            For count As Integer = 0 To numD20.Value - 1
                Dim intD20 As Double = Roll(20)
                valueHolder(count) = intD20
                count = count + 1
                strD20 = strD20 & "d20(" & intD20 & ") "
            Next
        End If

        lbLooker.Items.Add(strD4 & strD6 & strD8 & strD10 & strD12 & strD20)

        'Adding up the total
        Dim total As Integer = 0

        For count As Integer = 0 To valueHolder.Length - 1
            total = total + (valueHolder(count))
        Next

        txtTotal.Text = total

        'Resetting the array
        For count As Integer = 0 To valueHolder.Length - 1
            valueHolder(count) = 0
        Next

        'Resets the strings so they don't repeat themselves
        strD4 = ""
        strD6 = ""
        strD8 = ""
        strD10 = ""
        strD12 = ""
        strD20 = ""
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        'Resets everything
        ckbD4.Checked = False
        ckbD6.Checked = False
        ckbD8.Checked = False
        ckbD10.Checked = False
        ckbD12.Checked = False
        ckbD20.Checked = False

        numD4.Value = 0
        numD6.Value = 0
        numD8.Value = 0
        numD10.Value = 0
        numD12.Value = 0
        numD20.Value = 0

        strD4 = ""
        strD6 = ""
        strD8 = ""
        strD10 = ""
        strD12 = ""
        strD20 = ""

        lbLooker.Items.Clear()
        For count As Integer = 0 To valueHolder.Length - 1
            valueHolder(count) = 0
        Next

        txtTotal.Text = ""
    End Sub

    Function Roll(x As Double)
        'Making variables
        Dim num As Double

        '"Rolls" the dice and returns the number rolled
        num = Math.Ceiling(Rnd() * x)

        Return num
    End Function
End Class
